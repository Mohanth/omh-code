/*
const navSlide = () => {
    const burger = document.querySelector('.omh-global-header-toggle-btn');
    const nav = document.querySelector('.nav-list');
    const headerNav = document.querySelector('.nav');
    const navLinks = document.querySelectorAll('.nav-list li');

    burger.addEventListener('click', () => {
        nav.classList.toggle('nav-active');
        headerNav.classList.toggle('nav-active');


        navLinks.forEach((link, index) => {
            if(link.style.animation){
                link.style.animation = ''
            } else {
                link.style.animation = `navLinkFade 0.5s ease forwards ${index / 7 + 0}s`;
            }
        });

        burger.classList.toggle('toggle');

    });


}

navSlide();*/

document.querySelector('.omh-global-header-toggle-btn').addEventListener('click', function() {
    document.querySelector('.omh-nav-container').classList.toggle('active');
});
