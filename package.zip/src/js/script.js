document.querySelector('.omh-global-header-toggle-btn').addEventListener('click', function() {
    document.querySelector('.omh-nav-container').classList.toggle('active');
});
function toggleProfileMenu() {
    document.querySelector('.omh-user-info').classList.toggle('active');
}
function toggleMenu() {
    const navList = document.querySelector('.omh-menu-nav-container');
    navList.classList.toggle('active');

    const hamburgerIcon = document.querySelector('.omh-menu-toggle .fa-bars');
    const closeIcon = document.querySelector('.omh-menu-toggle .fa-times');


    // Toggle the visibility of the icons
    if (navList.classList.contains('active')) {
        hamburgerIcon.style.display = 'none';
        closeIcon.style.display = 'block';
    } else {
        hamburgerIcon.style.display = 'block';
        closeIcon.style.display = 'none';
    }
}

