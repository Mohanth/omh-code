document.querySelector('.omh-global-header-toggle-btn').addEventListener('click', function() {
    document.querySelector('.omh-nav-container').classList.toggle('active');
});
function toggleProfileMenu() {
    document.querySelector('.omh-user-info').classList.toggle('active');
}